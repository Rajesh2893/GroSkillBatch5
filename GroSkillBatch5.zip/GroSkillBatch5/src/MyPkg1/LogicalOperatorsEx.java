package MyPkg1;

public class LogicalOperatorsEx {

	public static void main(String[] args) {
		
		
		
		int a=10;
		int b=20;
		int c=15;
		
		if(a<c && b<c && a<b)
		{
			System.out.println("true");
		}
		
		else {
			
			System.out.println("false");
		}

	}

}
