package MyPkg1;

class A8
{
	int sum(int a,int b)
	{
		return a+b;
	}
}



public class MerthodsEx3 {

	public static void main(String[] args) {
		
		A8 obj=new A8();
	System.out.println(obj.sum(12, 45));	
		

	}

}
