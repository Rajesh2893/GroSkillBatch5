package MyPkg1;

public class LogicalOperators {

	public static void main(String[] args) {
		
		int a=10;
		int b=12;
		
		 if(a>=10 && b<15)
		 {
			 System.out.println("True");
		 }
		 
		 else
		 {
			 System.out.println("false");
		 }
		

	}

}
