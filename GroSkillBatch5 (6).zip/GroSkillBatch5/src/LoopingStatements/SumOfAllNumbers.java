package LoopingStatements;

public class SumOfAllNumbers {

	public static void main(String[] args) {
		
		int n=5;//
		
		int sum=0;
		
		int i=1;
		
		do
		{
			sum=sum+i;//sum=0+1=1//sum=1+2=3  ///  sum= 3+3=6 // sum =6+4=10/// sum=10+5=15
			i++;//1++//2++//3++ ///4++ //5++
			
		}
		
		while(i<=n);//2<=5//3<=5 /// 4<=5///5<=5  ///6<=5
		
		System.out.println("sum is  "+sum);
		
		

	}

}
