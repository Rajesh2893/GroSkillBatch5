package LoopingStatements;

public class ReverseNumber {

	public static void main(String[] args) {
		
		int num=121;
		
		int r=num;
		
		int rev=0;
		
		while(num!=0)//12!=0//1!=0//0!=0
		{
			
			int d= num%10;///d=3/// d=12%10=2//d=1%10=1
			rev= rev*10+d;/// rev= 0*10+3=3// rev=3*10+2=32//rev=32*10+1=321
			num=num/10;//num=123/10=12///num=12/10=1///num=1/10=0
			
			
		}
		
		System.out.println(rev);
		
		if(r==rev)
		{
			System.out.println("The number is palindrome");
		}
		
		else
		{
			System.out.println("Not palindrome");
		}
		

	}

}
