package StaticPkg;


class C7
{
	 C7()
	{
		System.out.println("How r u");
	}
	
	static void display()
	{
		System.out.println("Hello");
	}
	
	static 
	{
		System.out.println("Welcome");
	}
}


public class StaticBlockEx2 {

	public static void main(String[] args) {
		
		C7 obj=new C7();
		C7.display();
		
		

	}

}
