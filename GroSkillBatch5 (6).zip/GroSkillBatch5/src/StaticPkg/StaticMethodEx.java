package StaticPkg;

class B2
{
	static void display()
	{
		System.out.println("Hello");
	}
	
	static void test()
	{
		System.out.println("Hi");
	}
}


public class StaticMethodEx {

	public static void main(String[] args) {
		
		
		B2.display();
		B2.test();
		
		
	}

}
