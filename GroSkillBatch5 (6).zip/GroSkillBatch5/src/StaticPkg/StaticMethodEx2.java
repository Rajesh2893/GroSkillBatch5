package StaticPkg;

class B4
{
	static void test()
	{
		System.out.println("Hello");
	}
	
	
}

class B5 extends B4
{
	void test1()
	{
		System.out.println("Hi");
	}
	void message()
	{
		System.out.println("Hey");
	}
	
	void run()
	{
		test1();
		message();
		test();
	}
}



public class StaticMethodEx2 {

	public static void main(String[] args) {
		
		
		

	}

}
