package ThisKeyword;

class D1
{
	 int id;
	 String name;
	 float salary;
	
	D1(int id,String name,float salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+salary);
	}
	
	
}

public class ThisEx1 {

	public static void main(String[] args) {
		
		D1 obj=new D1(1234,"Harry",78000f);
		obj.display();
		

	}

}
