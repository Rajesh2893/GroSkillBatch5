package EncapsulationEx;

class Employee
{
	private int age;
	private String name;
	
	
	public int getAge() 
	{
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	}
public class EncapsulationEx1 {

	public static void main(String[] args) {
		
		Employee obj=new Employee();
		obj.setAge(45);
		
	System.out.println(obj.getAge());
	
	
	obj.setName("Harry");
	System.out.println(obj.getName());

		
		

	}

}
