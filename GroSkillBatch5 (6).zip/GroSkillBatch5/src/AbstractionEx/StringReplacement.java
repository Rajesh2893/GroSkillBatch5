package AbstractionEx;

public class StringReplacement {

	public static void main(String[] args) {
		String str="Tomorrow";
		 char []ch= str.toCharArray();
		 int count=1;
		 
		 StringBuilder sb=new StringBuilder();
		 char toreplace='o';
		 String replacementString="&";
		 
		 for(char x:ch)
		 {
			 if(x==toreplace)
			 {
				 sb.append(replacementString.repeat(count));
				 count++;
			 }
			 
			 else
			 {
				 sb.append(x);
			 }
		 }
		 
		 System.out.println(sb.toString());

	}

}
