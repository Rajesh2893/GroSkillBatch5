package AbstractionEx;

interface I11
{
	static void display()
	{
		System.out.println("Hello");
	}
	
	static int add(int x,int y)
	{
		return x+y;
	}
	
	static int add(int x,int y,int z)
	{
		return x+y+z;
	}
	
}





public class InterfaceEx6 {

	public static void main(String[] args) {
		
		I11.display();
		
	System.out.println(I11.add(13, 10));	
		
	System.out.println	(I11.add(12,15,20));

	}

}
