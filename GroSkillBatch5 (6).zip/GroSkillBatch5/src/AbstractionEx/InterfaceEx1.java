package AbstractionEx;

interface I1
{
	float pi=3.14f;
    void display();
    void test();
   
}

class E9 implements I1
{
	public void display()
	{
		System.out.println("Hello");
	}
	
	public void test()
	{
		System.out.println("Hi");
	}
	
	void area()
	{
		System.out.println(pi*5*5);
	}
}




public class InterfaceEx1 {

	public static void main(String[] args) {
		
		E9 obj=new E9();
		obj.test();
		obj.display();
		obj.area();
		
		

	}

}
