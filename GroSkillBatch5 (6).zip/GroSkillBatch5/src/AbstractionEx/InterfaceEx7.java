package AbstractionEx;

interface I12
{
	default void print()
	{
		System.out.println("Hello");
	}
}

class E12 implements I12
{
	
}




public class InterfaceEx7 {

	public static void main(String[] args) {
		
		I12 ref=new E12();
		ref.print();
		
		
		

	}

}
