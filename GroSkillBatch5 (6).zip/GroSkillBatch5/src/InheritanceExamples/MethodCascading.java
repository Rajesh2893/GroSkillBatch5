package InheritanceExamples;

class B1
{
	void display()
	{
		System.out.println("hello");
	}
	
	void test()
	{
		System.out.println("Hi");
	}
	
	void message()
	{
		display();
		test();
		System.out.println("How r u");
	}
	
}





public class MethodCascading {

	public static void main(String[] args) {
		
		B1 obj=new B1();
		obj.message();
		
		
		

	}

}
