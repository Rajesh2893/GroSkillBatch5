package InheritanceExamples;

class A9
{
	String colour="orange";
}
class A10 extends A9
{
	String colour="blue";
}

class A11 extends A10
{
	String colour="red";
	
	void display()
	{
		System.out.println(colour);
		System.out.println(super.colour);
	}
	
	
	
}





public class SuperEx1 {

	public static void main(String[] args) {
		
		A11 obj=new A11();
		obj.display();
		
		
		

	}

}
