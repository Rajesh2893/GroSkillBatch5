package InheritanceExamples;

class Animal
{
	String colour;
	String bark;
	
	Animal(String x,String y)
	{
		colour=x;
		bark=y;
		System.out.println(colour+"  "+bark);
		
	}
	
	Animal(String a)
	{
		colour=a;
	}
	
}

class Dog extends Animal
{
	Dog(String x,String y)
	{
		super(x,y);
		System.out.println("Dog created");
		
	}
	
	Dog(String k)
	{
		super(k);
	}
	
	
	
	
	
	
	
}

public class SuperConstructor {

	public static void main(String[] args) {
		
		Dog x=new Dog("blue","yes barking");
		
		

	}

}
