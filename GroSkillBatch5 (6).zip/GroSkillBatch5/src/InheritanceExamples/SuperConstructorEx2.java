package InheritanceExamples;


class C1
{
	String name;
	int id;
	
	C1(String n,int i)
	{
		name=n;
		id=i;
		System.out.println("C1 object");
	}
	
	C1(String k)
	{
		name=k;
	}
}

class C2 extends C1
{
	C2(String p,int q)
	{
		super(p,q);
		System.out.println("C2 object");
	}
	
	C2(String l)
	{
		super(l);
	}
	
	
	
	void display()
	{
		System.out.println(name+"   "+id);
	}
	
}








public class SuperConstructorEx2 {

	public static void main(String[] args) {
		
		C2 obj=new C2("Ramesh",1234);
		obj.display();
		
		

	}

}
