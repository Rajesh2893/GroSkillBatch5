package ConditionalStatements;

public class ifStatement {

	public static void main(String[] args) {
		
		
		int age=80;
		
		if(age>20  && age<40)
		{
			System.out.println("yes");
		}
		
		int a=20;
		int b=30;
		int c=a+b;
		System.out.println(c);
		
		
		

	}

}
