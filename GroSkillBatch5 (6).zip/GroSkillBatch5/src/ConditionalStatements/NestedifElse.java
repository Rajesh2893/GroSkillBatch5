package ConditionalStatements;

public class NestedifElse {

	public static void main(String[] args) {
		
		int a=20;
		int b=130;
		int c=35;
		
		if(a>b)
		{
			
			if(a>c)
			{
				System.out.println("a is maximum");
			}
			
			else
			{
				System.out.println("c is maximum");
			}
			
			
		}
		
		else
		{
			if(b>c)
			{
				System.out.println("b is maximum");
			}
			
			else
			{
				System.out.println("c is maximum");
			}
		}
		

	}

}
