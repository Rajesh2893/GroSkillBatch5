package MyPkg1;

public class TernaryOperator {

	public static void main(String[] args) {
		
		int a=10;
		
		int b=15;
		
		int c=30;
		
//		int max= a>b ? a:b;
//		
//		System.out.println(max);
		
		
		int max=  a>b ? (a>c?a:c) : (b>c?b:c);
		
		System.out.println(max);
		
		
		

	}

}
