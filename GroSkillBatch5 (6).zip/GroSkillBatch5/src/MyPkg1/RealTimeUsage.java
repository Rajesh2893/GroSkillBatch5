package MyPkg1;

class A13
{
	int eid;
	String name;
	
}



public class RealTimeUsage {

	public static void main(String[] args) {
		
		

	}

}
