package MyPkg1;

public class DataTypesEx1 {

	public static void main(String[] args) {
	
		boolean flag=true;
		
		//byte k=128;  ///-128 to +127
		
		
		short d=31456;   //  -32768 to +32767
		
		
		int e=1313122321;
		
		long t=1231231232132132L;
		
		float h=21321312321.123123212f;
		
		char ch='1';
		
		
		
		
		
		

	}

}
