package MyPkg1;

class A10
{
	void display()
	{
		
		
		
	}
}



public class DefaultConstructorUsage {

	public static void main(String[] args) {
		
		
		

	}

}
