package MyPkg1;

public class UnaryOperatorEx2 {

	public static void main(String[] args) {
		
		
		int a= 10;
		
		int b=20;
		
		int c=15;
		
		
		int d = a-- + c++ + b++ - --a + ++c - ++b;
		
		 /// d= 10 + 15 + 20 - 8 + 17 - 22
		
		/// a=9 , c=16 , b=21, 
		
		
		System.out.println(d);
		
		
		

	}

}
