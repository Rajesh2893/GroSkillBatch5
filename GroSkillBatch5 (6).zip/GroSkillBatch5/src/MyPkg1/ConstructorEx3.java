package MyPkg1;

class P1
{
	String name;
	int id;
	float salary;
	
	P1(String n,int i)
	{
		name=n;
		id=i;
	}
	
	P1(String m,float y)
	{
		name=m;
		salary=y;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+" "+salary);
	}
}



public class ConstructorEx3 {

	public static void main(String[] args) {
		
		P1 obj=new P1("saurabh",8234);
		obj.display();
		

	}

}
