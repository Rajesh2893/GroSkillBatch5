package MyPkg1;

class A11
{
	int id;
	String name;
	float salary;
	boolean isMarried;
	
	A11(int i,String n,float s)
	{
		id=i;
		name=n;
		salary=s;
		
	}
	
	A11(int j, String m,float x,boolean y)
	{
		id=j;
		name=m;
		salary=x;
		isMarried=y;
		
	}
	
	
	void display()
	{
		System.out.println(id+" "+name+"  "+salary +"  "+isMarried);
	}
}
	
	
	public class ParametrizedConstructor {

	public static void main(String[] args) {
		
		A11 obj=new A11(1234,"Harry",87000f);
		obj.display();
		
		A11 obj1=new A11(5678,"Tom",90000f,true);
		obj1.display();
		

	}

}
