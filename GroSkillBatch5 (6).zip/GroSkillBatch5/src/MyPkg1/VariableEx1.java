package MyPkg1;

class Test2
{
	
	int b=20;
	void display()
	{
		
		int a=10;
		System.out.println("Hello");
	}
	
	
	void test()
	{
		int c=b+20;
		
	}
}




public class VariableEx1 {

	public static void main(String[] args) {
		

	}

}
