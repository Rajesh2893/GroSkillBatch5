package PolymorphismEx;

public class OverloadingMainMethod {
	
	
	public static void main(String x)
	{
		System.out.println("Hello");
	}
	

	public static void main(String[] args) 
	{
		System.out.println("Hi");
		
		
	}

}
