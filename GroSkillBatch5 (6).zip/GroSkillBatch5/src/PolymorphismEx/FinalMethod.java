package PolymorphismEx;

class Bank1
{
	final int getROI(int x,int y)
	{
		return x+y;
	}
}

class HDFC extends Bank1
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}


class BOB extends Bank1
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}


public class FinalMethod {

	public static void main(String[] args) {
		

	}

}
