package PolymorphismEx;

class D6
{
	int add(int x,int y)
	{
		return x+y;
	}
	
	float add(int a,int b,int c)
	{
		return a+b+c;
	}
	
	float add(float a,int b,int c)
	{
		return a+b+c;
	}
}



public class PolyMorEx1 {

	public static void main(String[] args) {
		
		D6 obj=new D6();
		
	System.out.println(obj.add(12, 34));	
	System.out.println	(obj.add(45, 67,89));
	System.out.println	(obj.add(66.7f,54,99));
		
		
		
		

	}

}
