package PolymorphismEx;


final class D18
{
	void display()
	{
		System.out.println("Hello");
	}
}

class D19 extends D18
{
	void test()
	{
		System.out.println("Hi");
	}
}

public class FinalClass {

	public static void main(String[] args) {
		

	}

}
