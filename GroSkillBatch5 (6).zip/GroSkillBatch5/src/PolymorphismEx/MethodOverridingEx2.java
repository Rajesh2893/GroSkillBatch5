package PolymorphismEx;

class D9
{
	 static int sum(int x,int y)
	{
		return x+y;
	}
}

class D10 extends D9
{
	 int sum(int x,int y)
	{
		return x+y;
	}
}


public class MethodOverridingEx2 {

	public static void main(String[] args) {
		
		D10.sum(5, 5);
		

	}

}
