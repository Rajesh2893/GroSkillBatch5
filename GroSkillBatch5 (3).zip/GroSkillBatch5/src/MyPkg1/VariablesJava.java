package MyPkg1;

class A4
{
	int x=20;
	
	void test()
	{
		int a=10,b=20;
		int c=(a+b+x);
		System.out.println(c);
		
	}
	
	void sum()
	{
		int p=x+30;
		System.out.println(p);
	}
	
	
}

public class VariablesJava {

	public static void main(String[] args) {
		
		A4 obj=new A4();
		obj.sum();
		obj.test();
		
		
		

	}

}
