package MyPkg1;

public class MyTest1 {

	public static void main(String[] args) {
		
		System.out.println("Hello World");
		
//		System.out.println("HII");
//		
//		 System.out.print("Java");
		

	}

}
