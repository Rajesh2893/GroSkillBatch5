package MyPkg1;

class A6
{
	void display()
	{
		System.out.println("Hello");
	}
}



public class MethodsEx1 {

	public static void main(String[] args) {
		
		A6 obj=new A6();
		obj.display();
		

	}

}
