package InheritanceExamples;

class Shape
{
	void display()
	{
		System.out.println("I am displaying diagrams");
	}
}

class Rectangle extends Shape
{
	void test()
	{
		System.out.println("I have 4 sides");
	}
	
	
}
class Diagnoal extends Rectangle
{
	void message()
	{
		System.out.println("I bisect a rectangle");
	}
}
public class ShapeEx {

	public static void main(String[] args) {
		
		Diagnoal obj=new Diagnoal();
		obj.test();
		obj.display();
		obj.message();
		

	}

}
